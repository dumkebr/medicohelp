# MédicoHelp – Dr. Help (Replit)
Pronto para rodar no Replit com Vite + React + Tailwind.

## Como usar
1. Importe o `.zip` no Replit (Upload Folder) e extraia/importe todos os arquivos.
2. Abra o Shell do Replit e rode:
   ```sh
   npm install
   npm run dev
   ```
3. Abra a URL que o Replit exibir.

## Observações
- Modo Voz usa Web Speech API e funciona melhor no Chrome.
- Substitua `mockSendToDrHelp()` por sua chamada real de backend/LLM.
