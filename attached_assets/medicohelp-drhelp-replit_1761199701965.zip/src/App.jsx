import React from 'react'
import DrHelpChatShell from './DrHelpChat.jsx'

export default function App() {
  return <DrHelpChatShell />
}
