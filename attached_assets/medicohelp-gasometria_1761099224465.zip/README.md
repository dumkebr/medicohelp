# Calculadora de Gasometria – MédicoHelp
Arquivos prontos (HTML/JS/CSS) sem dependências. Abra `public/index.html`.
