// === Cálculos ===
const round = (v, n = 1) => (isFinite(v) ? Number(v.toFixed(n)) : null);
const asNumber = (el) => {
  const v = el.value.trim();
  return v === "" ? null : Number(v);
};

function calcAG({ Na, Cl, HCO3, K = null }) {
  if (Na == null || Cl == null || HCO3 == null) return { AG: null };
  const ag = (Na + (K ?? 0)) - (Cl + HCO3);
  return { AG: round(ag, 1) };
}
function correctAGforAlbumin(AG, albumin) {
  if (AG == null || albumin == null) return null;
  return round(AG + 2.5 * (4 - albumin), 1);
}
function winters(HCO3) {
  if (HCO3 == null) return null;
  const low = 1.5 * HCO3 + 8 - 2;
  const mid = 1.5 * HCO3 + 8;
  const high = 1.5 * HCO3 + 8 + 2;
  return { low: round(low), mid: round(mid), high: round(high) };
}
function expectedPaCO2MetAlk(HCO3) {
  if (HCO3 == null) return null;
  const mid = 0.7 * HCO3 + 20;
  return { low: round(mid - 5), mid: round(mid), high: round(mid + 5) };
}
function expHCO3RespAcid(PaCO2, chronic = false) {
  if (PaCO2 == null) return null;
  const delta = PaCO2 - 40;
  const per10 = chronic ? 3.5 : 1.0;
  return round(24 + (delta / 10) * per10, 1);
}
function expHCO3RespAlk(PaCO2, chronic = false) {
  if (PaCO2 == null) return null;
  const delta = 40 - PaCO2;
  const per10 = chronic ? 4.5 : 2.0;
  return round(24 - (delta / 10) * per10, 1);
}
function alveolarPAO2(PaCO2, FiO2 = 0.21, PB = 760, PH2O = 47, R = 0.8) {
  if (PaCO2 == null || FiO2 == null) return null;
  return round(FiO2 * (PB - PH2O) - PaCO2 / R, 1);
}
function AaGradient(PaO2, PaCO2, FiO2 = 0.21) {
  if (PaO2 == null || PaCO2 == null || FiO2 == null) return { PAO2: null, Aagrad: null };
  const PAO2 = alveolarPAO2(PaCO2, FiO2);
  return { PAO2, Aagrad: PAO2 != null ? round(PAO2 - PaO2, 1) : null };
}
function normalAaByAge(age) { return age != null ? round(age / 4 + 4, 0) : null; }
function pao2FiO2(PaO2, FiO2) { if (PaO2 == null || FiO2 == null || FiO2 === 0) return null; return round(PaO2 / FiO2, 0); }
function venousToArterial({ pH_v, PvCO2 }) {
  const pH_a = pH_v != null ? round(pH_v + 0.03, 2) : null;
  const PaCO2 = PvCO2 != null ? round(PvCO2 - 5, 0) : null;
  return { pH_a, PaCO2 };
}

function analyzeGas({
  arterial = true,
  pH, PaCO2, HCO3, Na, Cl, K, albumin, PaO2, FiO2, age,
  pH_v, PvCO2
}) {
  if (!arterial) {
    const conv = venousToArterial({ pH_v, PvCO2 });
    pH = pH ?? conv.pH_a;
    PaCO2 = PaCO2 ?? conv.PaCO2;
  }

  const { AG } = calcAG({ Na, Cl, HCO3, K });
  const AGcorr = correctAGforAlbumin(AG, albumin);
  const acidemia = pH != null && pH < 7.35;
  const alcalemia = pH != null && pH > 7.45;

  let prim = null;
  if (pH != null && PaCO2 != null && HCO3 != null) {
    if (acidemia) prim = (HCO3 < 22) ? "acidose metabólica" : (PaCO2 > 45 ? "acidose respiratória" : "indefinido");
    if (alcalemia) prim = (HCO3 > 26) ? "alcalose metabólica" : (PaCO2 < 35 ? "alcalose respiratória" : "indefinido");
  }

  let textoComp = "";
  if (prim === "acidose metabólica") {
    const w = winters(HCO3);
    if (w) textoComp += `Compensação esperada (Winter): PaCO₂ ~ ${w.mid} mmHg (faixa ${w.low}-${w.high}). `;
  }
  if (prim === "alcalose metabólica") {
    const m = expectedPaCO2MetAlk(HCO3);
    if (m) textoComp += `Em alcalose metabólica, PaCO₂ esperada ~ ${m.mid} mmHg (±5). `;
  }
  if (prim === "acidose respiratória") {
    const ag = expHCO3RespAcid(PaCO2, false);
    const ch = expHCO3RespAcid(PaCO2, true);
    textoComp += `Acidose respiratória: HCO₃⁻ esperado agudo ${ag} vs crônico ${ch}. `;
  }
  if (prim === "alcalose respiratória") {
    const ag = expHCO3RespAlk(PaCO2, false);
    const ch = expHCO3RespAlk(PaCO2, true);
    textoComp += `Alcalose respiratória: HCO₃⁻ esperado agudo ${ag} vs crônico ${ch}. `;
  }

  let deltaRatio = null;
  if (AGcorr != null && AGcorr > 12 && HCO3 != null) {
    const dAG = AGcorr - 12;
    const dHCO3 = 24 - HCO3;
    if (dHCO3 !== 0) deltaRatio = round(dAG / dHCO3, 2);
  }

  let oxi = {};
  if (arterial && PaO2 != null && FiO2 != null) {
    oxi = AaGradient(PaO2, PaCO2, FiO2);
    oxi.PF = pao2FiO2(PaO2, FiO2);
    oxi.AaNormalEst = normalAaByAge(age ?? null);
  }

  const partes = [];
  if (pH != null) partes.push(`pH ${pH}`);
  if (PaCO2 != null) partes.push(`PaCO₂ ${PaCO2} mmHg`);
  if (HCO3 != null) partes.push(`HCO₃⁻ ${HCO3} mEq/L`);
  if (AG != null) partes.push(`AG ${AG}` + (AGcorr != null ? ` (corrigido ${AGcorr})` : ""));

  let texto = `Gasometria ${arterial ? "arterial" : "venosa (convertida)"}: ${partes.join(", ")}. `;
  if (prim) texto += `Quadro primário sugere ${prim}. `;
  if (deltaRatio != null) texto += `Δ/Δ = ${deltaRatio}. `;
  if (textoComp) texto += textoComp;
  if (arterial && oxi.PAO2 != null) {
    texto += `PAO₂ ${oxi.PAO2} mmHg, gradiente A–a ${oxi.Aagrad} mmHg` +
             (oxi.AaNormalEst != null ? ` (normal ~${oxi.AaNormalEst}). ` : ". ");
    if (oxi.PF != null) texto += `PaO₂/FiO₂ ${oxi.PF}. `;
  }
  texto += "Conteúdo de apoio clínico. Validação e responsabilidade: médico usuário.";

  return { text: texto };
}

// === UI ===
const els = {
  tipo: document.querySelectorAll('input[name="tipo"]'),
  ph: document.getElementById("ph"),
  paco2: document.getElementById("paco2"),
  pvco2: document.getElementById("pvco2"),
  hco3: document.getElementById("hco3"),
  na: document.getElementById("na"),
  cl: document.getElementById("cl"),
  k: document.getElementById("k"),
  alb: document.getElementById("alb"),
  pao2: document.getElementById("pao2"),
  fio2: document.getElementById("fio2"),
  age: document.getElementById("age"),
  res: document.getElementById("resultado"),
  btnEx: document.getElementById("btnExemplo"),
  btnLimpar: document.getElementById("btnLimpar"),
  arterialOnly: document.querySelectorAll(".arterial-only"),
  venousOnly: document.querySelectorAll(".venous-only"),
};

function currentType() {
  return Array.from(els.tipo).find(r => r.checked)?.value === "arterial";
}
function refreshVisibility() {
  const isArt = currentType();
  els.arterialOnly.forEach(e => e.classList.toggle("hidden", !isArt));
  els.venousOnly.forEach(e => e.classList.toggle("hidden", isArt));
  compute();
}
function toFiO2fraction(v) {
  if (v == null) return null;
  if (v > 1) return v / 100;
  return v;
}
function compute() {
  const arterial = currentType();
  const payload = {
    arterial,
    pH: asNumber(els.ph),
    PaCO2: arterial ? asNumber(els.paco2) : null,
    HCO3: asNumber(els.hco3),
    Na: asNumber(els.na),
    Cl: asNumber(els.cl),
    K: asNumber(els.k),
    albumin: asNumber(els.alb),
    PaO2: arterial ? asNumber(els.pao2) : null,
    FiO2: arterial ? toFiO2fraction(asNumber(els.fio2)) : null,
    age: arterial ? asNumber(els.age) : null,
    pH_v: arterial ? null : asNumber(els.ph),
    PvCO2: arterial ? null : asNumber(els.pvco2),
  };
  const { text } = analyzeGas(payload);
  els.res.value = text;
}
function clearAll() {
  [els.ph, els.paco2, els.pvco2, els.hco3, els.na, els.cl, els.k, els.alb, els.pao2, els.fio2, els.age].forEach(el => el && (el.value = ""));
  compute();
}
els.tipo.forEach(r => r.addEventListener("change", refreshVisibility));
[els.ph, els.paco2, els.pvco2, els.hco3, els.na, els.cl, els.k, els.alb, els.pao2, els.fio2, els.age]
  .forEach(el => el && el.addEventListener("input", compute));
els.btnEx.addEventListener("click", () => {
  const isArt = currentType();
  els.ph.value = isArt ? "7.28" : "7.25";
  if (isArt) {
    els.paco2.value = "30"; els.pao2.value = "60"; els.fio2.value = "21"; els.age.value = "60";
  } else {
    els.pvco2.value = "35"; els.pao2.value = ""; els.fio2.value = ""; els.age.value = "";
  }
  els.hco3.value = "14"; els.na.value = "140"; els.cl.value = "105"; els.k.value = ""; els.alb.value = "3.0";
  compute();
});
els.btnLimpar.addEventListener("click", clearAll);
refreshVisibility(); compute();
