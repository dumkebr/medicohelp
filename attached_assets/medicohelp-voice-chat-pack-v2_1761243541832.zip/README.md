# MédicoHelp — Modo Voz (v2) com foto PNG da Dra. Clarice

- Microfone dentro do input
- Telefone fora, à direita
- Overlay “Ligando para Dra. Clarice...” com **PNG** incluso

## Replit
Secrets: `OPENAI_API_KEY` (obrigatório), `REALTIME_MODEL`, `REALTIME_VOICE` (opcionais)
Instalação: `npm install` → `npm start`
Front: importe `client/components/ChatComposer.jsx`