# MédicoHelp – Site oficial com imagens do usuário
Inclui:
- index.html (landing com logo oficial e PNG transparente da Dra. Clarice)
- partials/features.html (bloco O QUE É / RECURSOS / EM BREVE)
- css/style.css (tema verde/escuro)
- js/app.js (hooks e modais)
- assets/clarice.png, assets/logo-icon.png, assets/logo-lockup.png

Suba no Replit, extraia e rode. Pode substituir rotas usando window.MedicoHelp.*.
