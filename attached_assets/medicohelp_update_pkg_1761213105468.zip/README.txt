
# MédicoHelp — Pacote de Atualização (tema teal + logo correto + mascote + voz)

## O que vem pronto
- 🎨 **Tema novo** (teal/petróleo) + **modo escuro/claro** por CSS variables
- 🩺 **Logo oficial** (`/public/logo-medicohelp-horizontal.svg` e `logo-medicohelp-icon.svg`)
- 👩‍⚕️ **Mascote Dra. Clarice** (video WEBM com fallback PNG)
- 🗣️ **Voz Ember** configurável em `/src/config/voiceConfig.js`
- 🧱 **Home.jsx** com hero, CTAs e input (estrutura base)

## Como usar no Replit
1. Suba toda a pasta `public` e `src` para o seu projeto (substitua os arquivos existentes se necessário).
2. Coloque seus vídeos com alpha em:
   - `/public/clarice-idle.webm`
   - `/public/clarice-talking.webm`
   (enquanto isso, o fallback PNG aparece automaticamente)
3. Ajuste rotas conforme seu framework (se usar Vite/React, `App.jsx` já renderiza `Home`).

## Cores principais
- `--brand-800: #006C67`
- `--brand-500: #00A79D`
- Fundo escuro: `#0F1F22`

## Observações
- O SVG horizontal usa **Georgia/serif** para manter o ar clássico. Se quiser fixar a tipografia, podemos converter para caminhos (paths) em nova versão.
