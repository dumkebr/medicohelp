
export const VOICE_DEFAULT = "ember";
export const VOICE_FALLBACK = "cove";
export const speechRate = 0.92;  // veterana, pausado
export const pitch = -1;         // um pouco mais grave
