
import "../styles/theme.css";
import ThemeToggle from "../components/ThemeToggle";
import Mascote from "../components/Mascote";

export default function Home(){
  return (
    <main>
      <header className="header">
        <div className="logo-wrap">
          <img src="/logo-medicohelp-icon.svg" alt="Ícone MédicoHelp" height="26" />
          <div>
            <div style={{fontFamily:"Georgia,serif",fontSize:22,lineHeight:1}}>
              <span style={{color:"#FFFFFF"}}>Médico</span><span style={{color:"var(--brand-500)"}}>Help</span>
            </div>
            <div style={{fontSize:12,opacity:.85,color:"var(--muted)"}}>Sua aliada inteligente na decisão clínica</div>
          </div>
        </div>
        <ThemeToggle/>
      </header>

      <section className="hero">
        <Mascote speaking={false}/>
        <div>
          <h1 style={{margin:"0 0 8px"}}>Olá, eu sou a Dra. Clarice.</h1>
          <p style={{margin:"0 0 12px"}}>Sua aliada inteligente na decisão clínica.</p>
          <div style={{display:"flex",gap:12}}>
            <button className="button-primary">Modo clínico</button>
            <button className="button-outline">Modo evidências</button>
          </div>
        </div>
      </section>

      <section style={{margin:"0 24px 32px"}} className="card">
        <label htmlFor="msg" style={{display:"block",marginBottom:8}}>Envie uma mensagem</label>
        <div style={{display:"flex",gap:12,alignItems:"center"}}>
          <input id="msg" className="input" style={{flex:1}} placeholder="Digite sua mensagem..." />
          <button className="button-primary">Enviar</button>
        </div>
      </section>
    </main>
  );
}
