
MédicoHelp — Pacote de Atualização (V2)

O que inclui
- Tema teal/petróleo + modo escuro/claro (CSS variables)
- Logo oficial (horizontal + ícone) em SVG
- Mascote Dra. Clarice (fallback PNG; troque por WEBM quando tiver)
- Voz Ember configurável (voiceConfig.js)
- Home.jsx e App.jsx prontos

Como usar no Replit
1) Envie as pastas /public e /src para o seu projeto (substitua se pedir).
2) Adicione os vídeos com alpha em /public:
   - clarice-idle.webm
   - clarice-talking.webm
3) Rode o projeto.

Cores
- --brand-800: #006C67
- --brand-500: #00A79D
- Fundo escuro: #0F1F22
