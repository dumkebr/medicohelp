
export default function Mascote({ speaking=false }){
  const source = speaking ? "/clarice-talking.webm" : "/clarice-idle.webm";
  const fallback = speaking ? "/clarice-talking-fallback.png" : "/clarice-idle-fallback.png";
  return (
    <div style={{width:280}}>
      <video
        src={source}
        autoPlay
        loop
        muted
        playsInline
        style={{width:"100%",height:"auto",borderRadius:16,display:"block"}}
        onError={(e)=>{ e.currentTarget.outerHTML = `<img src='${fallback}' alt='Dra. Clarice' style='width:100%;border-radius:16px'/>`; }}
      />
    </div>
  );
}
