
import { useEffect, useState } from "react";

export default function ThemeToggle(){
  const [mode,setMode] = useState(localStorage.getItem("mh-theme")||"dark");
  useEffect(()=>{
    document.documentElement.classList.toggle("light", mode==="light");
    localStorage.setItem("mh-theme", mode);
  },[mode]);
  return (
    <button
      onClick={()=>setMode(m=>m==="dark"?"light":"dark")}
      style={{background:"none",border:"1px solid var(--border)",borderRadius:8,padding:"6px 10px",color:"var(--text)",cursor:"pointer"}}
      aria-label="Alternar tema"
      title={mode==="dark"?"Tema claro":"Tema escuro"}
    >
      {mode==="dark"?"☀️ Claro":"🌙 Escuro"}
    </button>
  );
}
