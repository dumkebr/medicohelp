
export const VOICE_DEFAULT = "ember";
export const VOICE_FALLBACK = "cove";
export const speechRate = 0.92;
export const pitch = -1;
