# Deploy automático (Replit → GitHub → Hostinger VPS)

## Fluxo recomendado
1. **Replit** para desenvolver e testar local.
2. **Push** para **GitHub** (branch `main`).
3. **GitHub Actions** envia para **Hostinger VPS** via SSH e sobe **Docker + Nginx**.

### Requisitos Hostinger
- VPS com Docker e Docker Compose instalados.
- Domínio apontado para o IP do VPS (A record).

### Passo a passo
1. No Replit: `npm install` → configurar `OPENAI_API_KEY` → rodar `npm start` e testar.
2. Conectar Replit ao GitHub e fazer *push* para `main`.
3. No GitHub, crie *Secrets* do repositório:
   - `SSH_HOST` (IP do VPS)
   - `SSH_PORT` (ex.: `22`)
   - `SSH_USER` (ex.: `root`)
   - `SSH_KEY` (conteúdo da chave privada)
   - `REMOTE_DIR` (ex.: `/opt/medicohelp`)
   - **No VPS**, exporte `OPENAI_API_KEY` no arquivo `.env` ou como variável do sistema ao rodar: `OPENAI_API_KEY=... docker compose up -d`
4. No VPS (primeira vez):
   ```bash
   apt-get update && apt-get install -y docker.io docker-compose-plugin
   mkdir -p /opt/medicohelp && cd /opt/medicohelp
   # O pipeline vai enviar os arquivos e rodar docker compose
   ```

## Alternativa (Hostinger compartilhado)
- Suba **apenas o front-end** (`index.html`, `styles.css`, `script.js`).
- No `script.js`, mude `API_URL` para o backend hospedado fora (Replit/Render/Vercel Functions).
